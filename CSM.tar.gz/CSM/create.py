import sys
j=int(sys.argv[1]);
print "CHIP PP"+str(j)+"{"
print " IN a[16];b;"
print " OUT out[32];"
print " PARTS:"
for i in range(16):
    print "   And(a=a["+str(i)+"],b=b,out=out["+str(i+j)+"]);"
print "}"