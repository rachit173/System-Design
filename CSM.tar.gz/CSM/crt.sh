
for i in {0..15}
do 
    python create.py $i>PP$i.hdl
done